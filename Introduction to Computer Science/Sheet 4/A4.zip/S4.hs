--4.3
--a)


isSpecialPrime :: Int -> Bool
isSpecialPrime n
 |elem n x == True = True
 |otherwise = False
  where 
   x= (filter isPrime (map(+1)(zipWith(+) (1:filter isPrime [1..n]) (filter isPrime[1..n]))))

isPrime :: Int -> Bool
isPrime x = check x (x `div` 2)

check :: Int -> Int -> Bool
check a b
 |b <= 0 = False
 |b == 1 = True
 |a `mod` b == 0 = False
 |otherwise = check a (b-1)